bee pack
docker build -t wtysos11/server:v1 .
